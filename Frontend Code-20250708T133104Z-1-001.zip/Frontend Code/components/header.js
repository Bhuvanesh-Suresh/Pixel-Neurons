import React from 'react';
import { Link } from 'react-router-dom';
import './header.css';

const Header = ({ user }) => {
    return (
        <header className="header">
            <div className="logo">
                <Link to="/" className="logo-link"> PN Healthcare Center</Link>
            </div>
            <nav className="nav-links">
                <Link to="/">Home</Link>
                <Link to="/about">About Us</Link>
                <Link to="/prediction">Prediction</Link>
                <Link to="/services">Services</Link>
                <Link to="/contact">Contact Us</Link>
                {!user ? (
                    <>
                        <Link to="/login">Login</Link>
                        <Link to="/signup">Signup</Link>
                    </>
                ) : (
                    <>
                        <span>Welcome, {user.username}</span>
                        <Link to="/logout">Logout</Link>
                    </>
                )}
            </nav>
        </header>
    );
};

export default Header;
