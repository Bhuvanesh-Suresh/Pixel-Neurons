import React from 'react';
import Lottie from 'react-lottie';
import animationData from '../assets/medical-animation.json'; // Ensure this path points to your Lottie JSON file

const AnimatedBackground = () => {
    const defaultOptions = {
        loop: true,
        autoplay: true,
        animationData,
        rendererSettings: {
            preserveAspectRatio: 'xMidYMid slice',
        },
    };

    return (
        <div
            style={{ 
                position: 'absolute', 
                top: '5%', // Slightly lowered the animation
                left: 0, 
                width: '100%', 
                height: '100%', 
                zIndex: -1,
                display: 'flex', 
                justifyContent: 'center', 
                alignItems: 'center', 
                filter: 'brightness(1.5)', // Increases brightness
                overflow: 'hidden', // Ensures the animation doesn't overflow
            }}
        >
            <Lottie options={defaultOptions} height={600} width={600} /> {/* Increased dimensions */}
        </div>
    );
};

export default AnimatedBackground;
