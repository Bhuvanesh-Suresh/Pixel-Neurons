// src/components/logout.js

import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Logout = ({ setUser }) => {
    const navigate = useNavigate();

    useEffect(() => {
        // Remove user data from state or local storage if any
        setUser(null);
        // Redirect to home page after logging out
        navigate('/');
    }, [setUser, navigate]);

    return <div>Logging you out...</div>;
};

export default Logout;
