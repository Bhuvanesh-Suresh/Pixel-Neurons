// src/components/servicecard.js

import React from 'react';

const ServiceCard = ({ title, description, image }) => {
    return (
        <div className="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-105 transition duration-300 ease-in-out">
            <div className="relative">
                <img
                    className="w-full h-56 object-cover rounded-lg"
                    src={image || "https://via.placeholder.com/600x400"} // Fallback image if no image is passed
                    alt={title}
                />
                <div className="absolute inset-0 bg-black opacity-25"></div>
            </div>
            <div className="p-6">
                <h3 className="text-2xl font-semibold text-indigo-600">{title}</h3>
                <p className="mt-2 text-base text-gray-600">{description}</p>
            </div>
        </div>
    );
};

export default ServiceCard;
