import React from 'react';

function Footer() {
    return (
        <footer className="footer">
            &copy; 2025 Medical Healthcare Center | All Rights Reserved.
        </footer>
    );
}

export default Footer;
