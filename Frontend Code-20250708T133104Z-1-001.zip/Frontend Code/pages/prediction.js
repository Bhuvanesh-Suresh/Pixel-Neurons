import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './prediction.css';

const Prediction = () => {
    const [selectedPrediction, setSelectedPrediction] = useState(null);
    const [diabetesFormData, setDiabetesFormData] = useState({
        Glucose: '',
        BloodPressure: '',
        SkinThickness: '',
        Insulin: '',
        BMI: '',
        Age: '',
    });

    const [bpFormData, setBpFormData] = useState({
        level_of_hemoglobin: '',
        age: '',
        bmi: '',
        sex: '',
        smoking: '',
        salt_content: '',
        stress_level: '',
        chronic_kidney_disease: '',
        thyroid_disorders: '',
        systolic_pressure: '',
        diastolic_pressure: '',
    });

    const [heartDiseaseFormData, setHeartDiseaseFormData] = useState({
        age: '',
        gender: '',
        height: '',
        weight: '',
        ap_hi: '',
        ap_lo: '',
        cholesterol: '',
        gluc: '',
        smoke: '',
        alco: '',
        active: '',
    });

    const [feverFormData, setFeverFormData] = useState({
        age: '',
        bmi: '',
        headache: '',
        bodyAche: '',
        chronicConditions: '',
        allergies: '',
        smokingHistory: '',
        alcohol: '',
        humidity: '',
        physicalActivity: '',
        heartRate: '',
        temperature: '',
    });

    const [result, setResult] = useState('');
    const [confidence, setConfidence] = useState('');
    const [condition, setCondition] = useState('');
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate();

    const handlePredictionClick = (predictionKey) => {
        setSelectedPrediction(predictionKey);
        setResult('');
        setConfidence('');
        setCondition('');
    };

    const handleInputChange = (e, formType) => {
        const { name, value } = e.target;
        const parsedValue = !isNaN(value) && value !== '' ? parseFloat(value) : value;

        if (formType === 'diabetes') {
            setDiabetesFormData({ ...diabetesFormData, [name]: parsedValue });
        } else if (formType === 'bp') {
            setBpFormData({ ...bpFormData, [name]: parsedValue });
        } else if (formType === 'heartDisease') {
            setHeartDiseaseFormData({ ...heartDiseaseFormData, [name]: parsedValue });
        } else if (formType === 'fever') {
            setFeverFormData({ ...feverFormData, [name]: parsedValue });
        }
    };

    const handleSubmit = async (e, formType) => {
        e.preventDefault();
        setLoading(true);

        let formData;
        let endpoint;
        if (formType === 'diabetes') {
            formData = diabetesFormData;
            endpoint = '/predict/diabetes';
        } else if (formType === 'bp') {
            formData = bpFormData;
            endpoint = '/predict/blood-pressure';
        } else if (formType === 'heartDisease') {
            formData = heartDiseaseFormData;
            endpoint = '/predict/heart-disease';
        } else if (formType === 'fever') {
            formData = feverFormData;
            endpoint = '/predict/fever';
        }

        if (Object.values(formData).some(value => value === '' || isNaN(value))) {
            setResult('Please fill all fields with valid values.');
            setLoading(false);
            return;
        }

        try {
            const response = await fetch(`http://127.0.0.1:5000${endpoint}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            const data = await response.json();
            if (response.ok) {
                setResult(data.result);
                setConfidence(data.confidence);
                setCondition(data.condition);
            } else {
                setResult(`Error: ${data.error || 'An unknown error occurred'}`);
            }
        } catch (error) {
            console.error(error);
            setResult('Error connecting to the backend.');
        }

        setLoading(false);
    };

    const labels = {
        diabetes: {
            Glucose: 'Glucose',
            BloodPressure: 'Blood Pressure',
            SkinThickness: 'Skin Thickness',
            Insulin: 'Insulin',
            BMI: 'BMI',
            Age: 'Age',
        },
        bp: {
            level_of_hemoglobin: 'Level of Hemoglobin',
            age: 'Age',
            bmi: 'BMI',
            sex: 'Sex (1 for Male, 0 for Female)',
            smoking: 'Smoking (1 for Yes, 0 for No)',
            salt_content: 'Salt Content (1-5)',
            stress_level: 'Stress Level (1-5)',
            chronic_kidney_disease: 'Chronic Kidney Disease (1 for Yes, 0 for No)',
            thyroid_disorders: 'Thyroid Disorders (1 for Yes, 0 for No)',
            systolic_pressure: 'Systolic Pressure',
            diastolic_pressure: 'Diastolic Pressure',
        },
        heartDisease: {
            age: 'Age',
            gender: 'Gender (1 for Male, 0 for Female)',
            height: 'Height (in cm)',
            weight: 'Weight (in kg)',
            ap_hi: 'Systolic Blood Pressure (ap_hi)',
            ap_lo: 'Diastolic Blood Pressure (ap_lo)',
            cholesterol: 'Cholesterol (1 = Normal, 2 = Above Normal, 3 = Well Above Normal)',
            gluc: 'Glucose (1 = Normal, 2 = Above Normal, 3 = Well Above Normal)',
            smoke: 'Do you smoke? (1 = Yes, 0 = No)',
            alco: 'Do you drink alcohol? (1 = Yes, 0 = No)',
            active: 'Are you physically active? (1 = Yes, 0 = No)',
        },
        fever: {
            age: 'Enter Age',
            bmi: 'Enter BMI',
            headache: 'Do you have Headache? (1 for Yes, 0 for No)',
            bodyAche: 'Do you have Body Ache? (1 for Yes, 0 for No)',
            chronicConditions: 'Do you have Chronic Conditions? (1 for Yes, 0 for No)',
            allergies: 'Do you have Allergies? (1 for Yes, 0 for No)',
            smokingHistory: 'Do you have Smoking History? (1 for Yes, 0 for No)',
            alcohol: 'Do you consume Alcohol? (1 for Yes, 0 for No)',
            humidity: 'Enter Humidity (%)',
            physicalActivity: 'What is your Physical Activity Level? (Moderate, Low, High)',
            heartRate: 'Enter Heart Rate (bpm)',
            temperature: 'Enter Temperature (°C)',
        },
    };

    const renderInputField = (label, key, formType) => {
        const value = formType === 'diabetes'
            ? diabetesFormData[key]
            : formType === 'bp'
            ? bpFormData[key]
            : formType === 'heartDisease'
            ? heartDiseaseFormData[key]
            : feverFormData[key];

        return (
            <div className="form-group" key={key}>
                <label>{label}: </label>
                <input
                    type={key === 'physicalActivity' ? 'text' : 'number'}
                    name={key}
                    value={value}
                    onChange={(e) => handleInputChange(e, formType)}
                    required
                />
            </div>
        );
    };

    return (
        <div className="prediction-container">
            <h1>Health Prediction</h1>
            <p>Use this tool to input your health data and receive predictions about your health status.</p>

            <div className="prediction-grid">
                <div className="prediction-box" onClick={() => handlePredictionClick('diabetes')}>
                    <h3>Diabetes Prediction</h3>
                </div>
                <div className="prediction-box" onClick={() => handlePredictionClick('bp')}>
                    <h3>Blood Pressure Prediction</h3>
                </div>
                <div className="prediction-box" onClick={() => handlePredictionClick('heartDisease')}>
                    <h3>Heart Disease Prediction</h3>
                </div>
                <div className="prediction-box" onClick={() => handlePredictionClick('fever')}>
                    <h3>Fever Prediction</h3>
                </div>
            </div>

            {selectedPrediction && labels[selectedPrediction] && (
                <div className="prediction-form">
                    <h2>{`${selectedPrediction.charAt(0).toUpperCase() + selectedPrediction.slice(1)} Prediction Form`}</h2>
                    <form onSubmit={(e) => handleSubmit(e, selectedPrediction)}>
                        {Object.entries(labels[selectedPrediction]).map(([key, label]) =>
                            renderInputField(label, key, selectedPrediction)
                        )}
                        <button type="submit" disabled={loading}>
                            {loading ? 'Predicting...' : 'Predict'}
                        </button>
                    </form>
                </div>
            )}

            {result && (
                <div className="prediction-result">
                    <h3>Prediction Result:</h3>
                    <p>{result}</p>
                    {confidence && <p>Confidence: {confidence}</p>}
                    {condition && <p>Condition: {condition}</p>}
                </div>
            )}

            <div className="chat-container" style={{ marginTop: '40px', textAlign: 'center' }}>
                <p className="chat-text" style={{ color: 'black', fontWeight: 'bold' }}>
                    For additional assistance, please connect with the Pixel Neurons AI Chatbot by clicking below.
                </p>
                <button
                    onClick={() => navigate('/chatbot')}
                    className="chatbot-link"
                    style={{
                        padding: '10px 15px',
                        fontSize: '16px',
                        marginTop: '10px',
                        display: 'inline-block',
                        backgroundColor: '#007bff',
                        color: 'white',
                        border: 'none',
                        borderRadius: '5px',
                        cursor: 'pointer',
                    }}
                >
                    Chat Now
                </button>
            </div>
        </div>
    );
};

export default Prediction;
