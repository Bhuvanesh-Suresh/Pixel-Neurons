import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './login.css';

const Login = ({ setUser }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null); // Error state for displaying messages
  const navigate = useNavigate();

  const handleLogin = async () => {
    // Simulate user authentication
    if (!username || !password) {
      setError("Please enter both username and password.");
      return;
    }

    try {
      // Mock API call to check username and password (replace with actual API call)
      // You can add API call to check credentials here

      setUser({ username });
      navigate('/'); // Redirect to home page after successful login
    } catch (err) {
      setError("Invalid username or password.");
    }
  };

  return (
    <div className="login-container">
      {/* Background animation div */}
      <div className="login-background"></div>

      <div className="login-form">
        <h2 className="login-title">Welcome Back</h2>
        <p className="login-description">Log in to your account to continue.</p>
        {error && <div className="error-message">{error}</div>} {/* Error message display */}
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            placeholder="Enter your username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button className="login-btn" onClick={handleLogin}>
          Login
        </button>
        <p className="login-footer">
          Don't have an account? <a href="/signup">Sign Up</a>
        </p>
      </div>
    </div>
  );
};

export default Login;
