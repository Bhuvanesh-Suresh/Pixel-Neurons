import React from 'react';
import Lottie from 'react-lottie';
import { motion } from 'framer-motion';
import animationData from '../assets/medical-animation.json';
import './home.css';


const pageTransition = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 },
};

const Home = ({ user }) => {
    const defaultOptions = {
        loop: true,
        autoplay: true,
        animationData: animationData,
        rendererSettings: {
            preserveAspectRatio: 'xMidYMid slice',
        },
    };

    const services = [
        {
            title: 'General Check-ups',
            description: 'Routine health monitoring to maintain overall well-being.',
        },
        {
            title: 'Pediatrics',
            description: 'Specialized care for children’s growth and development.',
        },
        {
            title: 'Emergency Care',
            description: 'Rapid-response services to address urgent medical needs.',
        },
    ];

    return (
        <motion.div
            initial="initial"
            animate="animate"
            exit="exit"
            variants={pageTransition}
            transition={{ duration: 0.4, ease: 'easeOut' }}
        >
            <div className="home-container">
                {/* Hero Section */}
                <section className="hero-section">
                    <div className="hero-content">
                        <h1 className="hero-heading">Pixel Neurons Healthcare Centre</h1>
                        <p className="hero-description">
                            Experience cutting-edge medical services tailored for you.
                        </p>
                        {user ? (
                            <p className="welcome-message">Hello, {user.username}! Glad to see you.</p>
                        ) : (
                            <p className="login-message">Sign in to explore personalized health insights.</p>
                        )}
                    </div>
                </section>

                {/* Services Section */}
                <section className="services-overview">
                    <div className="background-animation">
                        <Lottie options={defaultOptions} height={240} width={270} />
                    </div>

                    <h2 className="services-title">Explore Our Services</h2>

                    <div className="service-list">
                        {services.map((service, index) => (
                            <motion.div
                                key={index}
                                className="service-card"
                                whileHover={{
                                    scale: 1.05,
                                    boxShadow: '0px 12px 20px rgba(0, 0, 0, 0.2)',
                                }}
                            >
                                <h3 className="service-title">{service.title}</h3>
                                <p className="service-description">{service.description}</p>
                            </motion.div>
                        ))}
                    </div>
                </section>
            </div>
        </motion.div>
    );
};

export default Home;
