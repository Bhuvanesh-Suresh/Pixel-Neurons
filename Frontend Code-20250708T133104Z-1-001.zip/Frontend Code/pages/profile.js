import React from 'react';

const Profile = ({ user }) => {
    return (
        <div>
            <h2>Welcome to your Profile, {user.username}!</h2>
            {/* Add more details about the user here */}
        </div>
    );
};

export default Profile;
