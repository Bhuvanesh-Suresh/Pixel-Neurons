import React from 'react';
import './services.css';

const Services = () => {
  return (
    <div className="services-container">
      <h1 className="services-heading">Our Healthcare Services</h1>
      <p className="services-description">
        We provide a wide range of high-quality medical services to ensure your well-being and care.
      </p>

      <div className="services-cards">
        <div className="service-card">
          <div className="service-icon">
            <i className="fas fa-stethoscope"></i>
          </div>
          <h2 className="service-title">General Consultation</h2>
          <p className="service-text">
            Get professional and personalized consultation from experienced doctors for your health concerns.
          </p>
        </div>

        <div className="service-card">
          <div className="service-icon">
            <i className="fas fa-pills"></i>
          </div>
          <h2 className="service-title">Pharmacy Services</h2>
          <p className="service-text">
            We provide a full range of medicines with expert advice on usage and side effects.
          </p>
        </div>

        <div className="service-card">
          <div className="service-icon">
            <i className="fas fa-ambulance"></i>
          </div>
          <h2 className="service-title">Emergency Care</h2>
          <p className="service-text">
            Our emergency services are available 24/7 to provide immediate assistance for critical cases.
          </p>
        </div>

        <div className="service-card">
          <div className="service-icon">
            <i className="fas fa-heartbeat"></i>
          </div>
          <h2 className="service-title">Cardiology</h2>
          <p className="service-text">
            Specialized heart care services, including diagnostics, treatment, and ongoing monitoring.
          </p>
        </div>

        <div className="service-card">
          <div className="service-icon">
            <i className="fas fa-brain"></i>
          </div>
          <h2 className="service-title">Neurology</h2>
          <p className="service-text">
            Comprehensive treatment for neurological conditions, including advanced diagnostics and therapies.
          </p>
        </div>

        <div className="service-card">
          <div className="service-icon">
            <i className="fas fa-bone"></i>
          </div>
          <h2 className="service-title">Orthopedic Services</h2>
          <p className="service-text">
            Our orthopedic specialists offer treatment for bone, joint, and muscle-related conditions.
          </p>
        </div>

        <div className="service-card">
          <div className="service-icon">
            <i className="fas fa-user-md"></i>
          </div>
          <h2 className="service-title">Pediatric Care</h2>
          <p className="service-text">
            Providing specialized healthcare services for children, including routine check-ups and vaccinations.
          </p>
        </div>

        <div className="service-card">
          <div className="service-icon">
            <i className="fas fa-flask"></i>
          </div>
          <h2 className="service-title">Laboratory Services</h2>
          <p className="service-text">
            Advanced diagnostic tests and lab work to provide accurate and timely results for better treatment planning.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Services;
