import React, { useState, useEffect, useRef } from 'react';
import './chatbot.css';

const Chatbot = () => {
    const [question, setQuestion] = useState('');
    const [loading, setLoading] = useState(false);
    const [chatHistory, setChatHistory] = useState([]);
    const [isListening, setIsListening] = useState(false);
    const chatHistoryRef = useRef(null);

    const MAX_RESPONSE_LENGTH = 200;

    // Scroll to the bottom whenever new messages are added
    useEffect(() => {
        chatHistoryRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [chatHistory]);

    const handleVoiceInput = () => {
        if (!('webkitSpeechRecognition' in window)) {
            alert('Voice recognition is not supported in this browser. Please use Chrome or Edge.');
            return;
        }

        const recognition = new window.webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => setIsListening(true);
        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            setQuestion(transcript);
            setIsListening(false);
        };
        recognition.onerror = () => setIsListening(false);
        recognition.onend = () => setIsListening(false);

        recognition.start();
    };

    const handleInputChange = (event) => setQuestion(event.target.value);

    const handleSubmit = async (event) => {
        event.preventDefault();
        if (question.trim() === '') return;

        // Immediately display the user's question in the chat history
        const userMessage = { text: question, sender: 'user' };
        setChatHistory(prevHistory => [...prevHistory, userMessage]);  // Add the user message first

        setLoading(true);

        try {
            let answer = '';

            // Handle special cases like prescribing medicine
            if (question.toLowerCase().includes('prescribe medicine') || question.toLowerCase().includes('diabetes medicine')) {
                answer = `I am an AI-powered chatbot and do not have the qualifications to prescribe medicine. Please consult your healthcare provider.`;
            } else {
                // Send the user's question to the backend for processing
                const response = await fetch('http://localhost:5000/api/generate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ question }),
                });

                const data = await response.json();
                answer = data.answer || `Error: ${data.error}`;
            }

            // Truncate long answers
            const truncatedAnswer = answer.length > MAX_RESPONSE_LENGTH ? answer.substring(0, MAX_RESPONSE_LENGTH) + '...' : answer;

            // Add the bot's response to the chat history
            const botMessage = { text: truncatedAnswer, sender: 'bot' };
            setChatHistory(prevHistory => [...prevHistory, botMessage]);  // Add the bot's response

        } catch (error) {
            console.error('Error fetching answer:', error);
            setChatHistory(prevHistory => [...prevHistory, { text: 'Sorry, there was an error while fetching the answer.', sender: 'bot' }]);
        }

        setLoading(false);
        setQuestion('');
    };

    return (
        <div className="chatbot-container">
            <header className="chatbot-header">
                <h1>PIXELS NEURONS AI CHATBOT</h1>
                <p className="intro-text">How can we assist you with your medical questions today?</p>
            </header>

            <div className="chat-history">
                {chatHistory.map((message, index) => (
                    <div
                        key={index}
                        className={`chat-message ${message.sender === 'user' ? 'user-message' : 'bot-message'}`}
                    >
                        <p>{message.text}</p>
                    </div>
                ))}
                <div ref={chatHistoryRef}></div>
            </div>

            <form onSubmit={handleSubmit} className="chat-form">
                <div className="input-wrapper">
                    <input
                        type="text"
                        value={question}
                        onChange={handleInputChange}
                        placeholder="Ask a medical queries..."
                        className="chat-input"
                    />
                    <button
                        type="button"
                        className={`voice-button ${isListening ? 'listening' : ''}`}
                        onClick={handleVoiceInput}
                    >
                        <i className="fas fa-microphone"></i>
                    </button>
                </div>
                <button type="submit" className="ask-button" disabled={loading}>
                    <i className="fas fa-paper-plane"></i> {/* Sleek Paper Plane Icon */}
                </button>
            </form>
        </div>
    );
};

export default Chatbot;
