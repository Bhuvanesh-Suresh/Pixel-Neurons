import React from 'react';
import './about.css';

const About = () => {
  return (
    <div className="about-container">
      <div className="about-header">
        <h1>About Us</h1>
        <p>Your health, our priority!</p>
      </div>
      <div className="about-content">
        <div className="about-text">
          <h2>Our Mission</h2>
          <p>
            At [Your Company Name], our mission is to provide top-notch healthcare services that
            cater to the needs of our patients with compassion, efficiency, and excellence. We aim
            to improve lives through advanced healthcare and personalized care.
          </p>
          <h2>What We Do</h2>
          <p>
            We offer a range of medical services, including consultations, diagnostics, treatments,
            and preventive care. Our expert team ensures that every patient receives personalized
            care, making use of the latest medical technologies and best practices to improve patient
            outcomes.
          </p>
        </div>
      </div>
      <div className="about-team">
        <h2>Meet Our Team</h2>
        <div className="team-members">
          <div className="team-member">
            <h3>Dr. John Doe</h3>
            <p>Chief Medical Officer</p>
          </div>
          <div className="team-member">
            <h3>Dr. Jane Smith</h3>
            <p>Pediatric Specialist</p>
          </div>
          <div className="team-member">
            <h3>Dr. Emily White</h3>
            <p>Cardiologist</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
