import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Home from './pages/home';
import About from './pages/about';
import Services from './pages/services';
import Contact from './pages/contact';
import Login from './pages/login';
import Signup from './pages/signup';
import Profile from './pages/profile';
import Prediction from './pages/prediction'; // Import Prediction component
import Chatbot from './pages/chatbot'; // Import Chatbot component
import Header from './components/header';
import Footer from './components/footer';
import Logout from './components/logout'; // Import Logout component
import './app.css'; // Global styles
import './index.css';

function App() {
  const [user, setUser] = useState(null); // State to hold logged-in user information

  return (
    <Router>
      <Header user={user} />
      <main>
        <Routes>
          <Route path="/" element={<Home user={user} />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/login" element={<Login setUser={setUser} />} />
          <Route path="/signup" element={<Signup />} />
          <Route
            path="/profile"
            element={user ? <Profile user={user} /> : <Navigate to="/login" />}
          />
          <Route path="/prediction" element={<Prediction />} /> {/* Prediction Route */}
          <Route path="/chatbot" element={<Chatbot />} /> {/* Chatbot Route */}
          <Route path="/logout" element={<Logout setUser={setUser} />} /> {/* Logout Route */}
          <Route path="*" element={<Navigate to="/" />} /> {/* Redirect unknown routes */}
        </Routes>
      </main>
      <Footer />
    </Router>
  );
}

export default App;
