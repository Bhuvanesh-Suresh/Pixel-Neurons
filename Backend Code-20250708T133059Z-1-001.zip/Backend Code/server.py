import os
import google.generativeai as genai
from flask import Flask, request, jsonify
from flask_cors import CORS

# Initialize Flask app
app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# Set Google API Key
GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY", "AIzaSyDU6Y6eC8hy9EA9v8XDFrYfbSKxrfxa8GQ")

# Configure the Gemini API
genai.configure(api_key=GOOGLE_API_KEY)

# Define a route to generate responses
@app.route("/api/generate", methods=["POST"])
def generate_response():
    try:
        req_body = request.get_json()
        content = req_body.get("question")

        if not content:
            return jsonify({"error": "No question provided"}), 400

        model = genai.GenerativeModel("gemini-1.5-flash")
        response = model.generate_content(content)

        if response and response.text:
            return jsonify({"answer": response.text})
        else:
            return jsonify({"error": "No response from Gemini API"}), 500

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Add a route to serve the chatbot page
@app.route('/chatbot')
def chatbot():
    return jsonify({"message": "Chatbot is ready to assist you!"})

# Home route
@app.route('/')
def home():
    return "Welcome to the Medical Chatbot API!"

# Run the app
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
