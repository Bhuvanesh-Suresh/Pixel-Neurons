from flask import Flask, request, jsonify, render_template
import tensorflow as tf
import numpy as np
from sklearn.preprocessing import StandardScaler
import pandas as pd

# Initialize Flask app
app = Flask(__name__, template_folder='templates')

# Load the model
model = tf.keras.models.load_model('fever_model.h5')

# Load and preprocess training data to initialize the scaler
df = pd.read_json('updated_data.json', lines=True)
data = df.to_dict('records')

# Extract features for scaling
X = []
for entry in data:
    features = [
        float(entry['Age']),
        float(entry['BMI']),
        1 if entry['Headache'] == 'Yes' else 0,
        1 if entry['Body_Ache'] == 'Yes' else 0,
        1 if entry['Chronic_Conditions'] == 'Yes' else 0,
        1 if entry['Allergies'] == 'Yes' else 0,
        1 if entry['Smoking_History'] == 'Yes' else 0,
        1 if entry['Alcohol_Consumption'] == 'Yes' else 0,
        float(entry['Humidity']),
        1 if entry['Physical_Activity'] == 'Moderate' else 0,
        float(entry['Heart_Rate']),
    ]
    X.append(features)

X = np.array(X)

# Initialize and fit the scaler
scaler = StandardScaler()
scaler.fit(X)

# Serve the index.html page
@app.route('/')
def index():
    return render_template('index.html')

# Prediction endpoint
@app.route('/predict', methods=['POST'])
def predict():
    try:
        input_data = request.json
        
        # Extract input features
        features = [
            float(input_data['Age']),
            float(input_data['BMI']),
            1 if input_data['Headache'].lower() == 'yes' else 0,
            1 if input_data['Body_Ache'].lower() == 'yes' else 0,
            1 if input_data['Chronic_Conditions'].lower() == 'yes' else 0,
            1 if input_data['Allergies'].lower() == 'yes' else 0,
            1 if input_data['Smoking_History'].lower() == 'yes' else 0,
            1 if input_data['Alcohol_Consumption'].lower() == 'yes' else 0,
            float(input_data['Humidity']),
            1 if input_data['Physical_Activity'].lower() == 'moderate' else 0,
            float(input_data['Heart_Rate']),
        ]
        
        temperature = float(input_data['Temperature'])

        # Normalize the features
        features = scaler.transform([features])

        # Model predictions
        predictions = model.predict(features)

        # Decode predictions
        fever_severity = np.argmax(predictions[0], axis=1)[0]
        fever_type = np.argmax(predictions[1], axis=1)[0]
        medication_class = np.argmax(predictions[2], axis=1)[0]

        # Map predictions to labels
        fever_severity_map = {0: "Normal", 1: "Low", 2: "High"}
        fever_type_map = {0: "No Fever", 1: "Viral", 2: "Bacterial"}
        medication_map = {0: "None", 1: "Paracetamol", 2: "Ibuprofen"}

        severity = fever_severity_map[fever_severity]
        fever_type_result = fever_type_map[fever_type]
        medication = medication_map[medication_class]

        # Adjust based on temperature
        if temperature < 37:
            severity = "Normal"
            fever_type_result = "No Fever"
            medication = "None"
        elif 37 <= temperature < 38:
            severity = "Low"
            medication = "Paracetamol"
        elif temperature >= 38:
            severity = "High"
            medication = "Ibuprofen"

        # Return predictions
        return jsonify({
            "Fever Severity": severity,
            "Fever Type": fever_type_result,
            "Recommended Medication": medication,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
