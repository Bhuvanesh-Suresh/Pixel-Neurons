import torch
import torch.nn as nn

# Define the neural network model (match the trained model architecture)
class DiabetesNN(nn.Module):
    def __init__(self, input_size):
        super(DiabetesNN, self).__init__()
        # Adjust layer sizes according to the trained model's architecture
        self.fc1 = nn.Linear(input_size, 128)  # Match the trained model (128 units)
        self.fc2 = nn.Linear(128, 64)          # Match the trained model (64 units)
        self.fc3 = nn.Linear(64, 1)            # Match the trained model (1 output unit)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = torch.relu(self.fc1(x))  # First hidden layer
        x = torch.relu(self.fc2(x))  # Second hidden layer
        x = self.sigmoid(self.fc3(x))  # Output layer
        return x
